﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript2D : MonoBehaviour
{
    public Transform player;
    public Vector3 offset;

    private void Start()
    {
        offset = transform.position - player.transform.position;
    }
    private void LateUpdate()
    {
        transform.position = player.transform.position + offset;
    }
}
