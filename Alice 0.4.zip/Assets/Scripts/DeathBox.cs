﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DeathBox : MonoBehaviour
{
    Kretanje zivot;
    GameManager zivotUI;

    private void Start()
    {
        zivot = FindObjectOfType<Kretanje>();
        zivotUI = FindObjectOfType<GameManager>();
    }
    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "Player")
        {
            zivot.trenutniZivot -= 1000;
            zivotUI.currentHP.text = zivot.trenutniZivot.ToString();
        }
    }
}
