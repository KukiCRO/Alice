﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mac_Script : MonoBehaviour
{
    public Animator anim_mac;
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.J))
        {
            anim_mac.Play("MacNapad");
        }
    }
    

private void OnTriggerEnter(Collider other)
    {
        
        if (other.gameObject.tag == "Enemy")
        {
            Destroy(other.gameObject);
        }
    }
}
