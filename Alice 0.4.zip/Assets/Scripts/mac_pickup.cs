﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mac_pickup : MonoBehaviour
{
    public Kretanje sword;
    private void Start()
    {
        sword = FindObjectOfType<Kretanje>();
    }
    private void OnTriggerEnter(Collider other)
    {
        if(other.gameObject.tag == "Player")
        {
            sword.mac.SetActive(true);
            Destroy(this.gameObject);
        }
    }
}
